import pgzrun
import os
import random
from pgzhelper import *

os.environ['SDL_VIDEO_CENTERED'] = '1'

WIDTH = 1000
HEIGHT = 700
TITLE = 'GAME CENTER'
button_pos = 0, 0
#-------------------------- main menu --------------------------#
main_menu_background = Actor('main_menu_background', (500, 350))
game_center_logo = Actor('game_center_logo', (1050, 220))
games_button = Actor('games_button_idle', (500, 800))
info_button = Actor('info_button_idle', (110, 700))
shop_button = Actor('shop_button_idle', (890, 700))
exit_button = Actor('exit_button_idle', (735, 700))
setting_button = Actor('setting_button_idle', (265, 635))
main_menu_button = Actor('main_menu_button_idle', (500, 800))
pink_background = Actor('pink_background', (500, 350))
busy_street_logo = Actor('busy_street_logo_idle', (250,450))
candy_eater_logo = Actor('candy_eater_logo_idle', (750,450))
collector_logo = Actor('collector_logo_idle', (250, 250))
dino_logo = Actor('dino_logo_idle', (750, 250))
exit_panel = Actor('exit_panel', (500,350))
no_button = Actor('no_idle', (688, 422))
yes_button = Actor('yes_idle', (306, 422))
game_choosing = False
main_menu_exit = False

def button_out_of_screen():
    games_button.y = 800
    info_button.y = 800
    exit_button.y = 800
    shop_button.y = 800
    setting_button.y = 800
    game_center_logo.x = 1300

#---------------- common buttons Actor ----------------#
home_button = Actor('home_button_idle')
play_button = Actor('play_button_idle')
repeat_button = Actor('repeat_button_idle')
guide_button = Actor('guide_button_idle')
music_on_button = Actor('music_on_button_idle')
music_off_button = Actor('music_off_button_idle')
key_up = Actor('key_up_idle')
key_down = Actor('key_down_idle')
key_right = Actor('key_right_idle')
key_left = Actor('key_left_idle')
key_space = Actor('key_space_idle')
in_game_setting_button = Actor('pink_in_game_setting_idle')
score_button = Actor('pink_score_button_idle')
in_game_setting = False
music = True

#--------------------- busy street game---------------------#
left_car_list = ['police_car', 'left_car']
busy_street_road = Actor('busy_street_road', (500, 400))
player_car = Actor('player_car_down', (562, 100))
left_car = Actor(random.choice(left_car_list), (100, 332))
right_car = Actor('right_car', (900, 466))
police_car = Actor('police_car')
lamp_1 = Actor('lamp1', (399, 213))
lamp_2 = Actor('lamp2', (600, 585))
lamp_3 = Actor('lamp3', (315, 501))
lamp_4 = Actor('lamp4', (683, 298))
black_lamp_1 = Actor('black_lamp1', (500, 400))
black_lamp_2 = Actor('black_lamp2', (510, 400))
black_lamp_3 = Actor('black_lamp3', (513, 399))
pink_game_over_panel = Actor('pink_game_over_panel', (500, 350))
busy_street_guide_panel = Actor('busy_street_guide', (500, 350))
pink_panel = Actor('pink_panel', (500,350))
busy_street_game = False
busy_street_game_over = False
busy_street_guide = False
right_car_speed = random.randint(2,15)
left_car_speed = random.randint(2,15)
players_car_speed = 5
busy_street_score = 0

#--------------------- candy eater game---------------------#
candy_eater_background = Actor('candy_eater_background', (600,350))
blue_panel = Actor('blue_panel', (500, 350))
blue_game_over_logo = Actor('blue_game_over', (500,350))
heart_1 = Actor('heart', (50, 40))
heart_2 = Actor('heart', (50, 60))
heart_3 = Actor('heart', (50, 80))
candy_eater_guide_panel = Actor('candy_eater_guide', (500, 350))
healthy_food_list = ['banana', 'apple', 'onion_1', 'onion_2', 'potato', 'cheese_1', 'cheese_2', 'cheese_wheel', 'cheeses', 'coconut', 'corn_1', 'corn_2', 'eggplant', 'fruit_bowl_1', 'fruit_bowl_2', 'fruit_bowl_3', 'grapes', 'olive', 'rice_bowl', 'rice_fried', 'rice_steamed', 'tangerine_slice', 'tomato', 'vegetable_tray']
unhealthy_food_list = ['doughnut', 'croissant', 'cupcake', 'gelatin', 'pie', 'flummery', 'ice_cream_bar_1', 'ice_cream_bar_2', 'cookie']

unhealthy_food = Actor(random.choice(unhealthy_food_list), (random.randint(60, 950), -20))
healthy_food = Actor(random.choice(healthy_food_list), (random.randint(60, 950), -20))

pink_girl = Actor('pink_girl_idle_1', (500, 550))
pink_girl.images = ['pink_girl_idle_2', 'pink_girl_idle_3', 'pink_girl_idle_4', 'pink_girl_idle_5', 'pink_girl_idle_6', 'pink_girl_idle_7', 'pink_girl_idle_8', 'pink_girl_idle_9', 'pink_girl_idle_10', 'pink_girl_idle_11', 'pink_girl_idle_12', 'pink_girl_idle_13', 'pink_girl_idle_14', 'pink_girl_idle_15', 'pink_girl_idle_16']
pink_girl.fps = 10

pink_girl_jump_up = Actor('pink_girl_jump_1', (500, 200))
pink_girl_jump_up.images = ['pink_girl_jump_2', 'pink_girl_jump_3', 'pink_girl_jump_4', 'pink_girl_jump_5', 'pink_girl_jump_6', 'pink_girl_jump_7', 'pink_girl_jump_8', 'pink_girl_jump_9', 'pink_girl_jump_10', 'pink_girl_jump_11', 'pink_girl_jump_12', 'pink_girl_jump_13', 'pink_girl_jump_14']
pink_girl_jump_up.fps = 20

pink_girl_jump_down = Actor('pink_girl_jump_15', (500, 200))
pink_girl_jump_down.images = ['pink_girl_jump_16', 'pink_girl_jump_17', 'pink_girl_jump_18', 'pink_girl_jump_19', 'pink_girl_jump_20', 'pink_girl_jump_21', 'pink_girl_jump_22', 'pink_girl_jump_23', 'pink_girl_jump_24', 'pink_girl_jump_25', 'pink_girl_jump_26', 'pink_girl_jump_27', 'pink_girl_jump_28', 'pink_girl_jump_29', 'pink_girl_jump_30']
pink_girl_jump_down.fps = 20

pink_girl_walk = Actor('pink_girl_walk_1', (500, 200))
pink_girl_walk.images = ['pink_girl_walk_2', 'pink_girl_walk_3', 'pink_girl_walk_4', 'pink_girl_walk_5', 'pink_girl_walk_6', 'pink_girl_walk_7', 'pink_girl_walk_8', 'pink_girl_walk_9', 'pink_girl_walk_10', 'pink_girl_walk_11', 'pink_girl_walk_12', 'pink_girl_walk_13', 'pink_girl_walk_14', 'pink_girl_walk_15', 'pink_girl_walk_16', 'pink_girl_walk_17', 'pink_girl_walk_18', 'pink_girl_walk_19', 'pink_girl_walk_20']
pink_girl_walk.fps = 13

pink_girl_dead = Actor('pink_girl_dead_1', (500, 200))
pink_girl_dead.images = ['pink_girl_dead_2', 'pink_girl_dead_3', 'pink_girl_dead_4', 'pink_girl_dead_5', 'pink_girl_dead_6', 'pink_girl_dead_7', 'pink_girl_dead_8', 'pink_girl_dead_9', 'pink_girl_dead_10', 'pink_girl_dead_11', 'pink_girl_dead_12', 'pink_girl_dead_13', 'pink_girl_dead_14', 'pink_girl_dead_15', 'pink_girl_dead_16', 'pink_girl_dead_17', 'pink_girl_dead_18', 'pink_girl_dead_19', 'pink_girl_dead_20', 'pink_girl_dead_21', 'pink_girl_dead_22', 'pink_girl_dead_23', 'pink_girl_dead_24', 'pink_girl_dead_25', 'pink_girl_dead_26', 'pink_girl_dead_27', 'pink_girl_dead_28', 'pink_girl_dead_29', 'pink_girl_dead_30']
pink_girl_dead = Actor('pink_girl_dead_1')
pink_girl_dead.fps = 10

candy_eater_game = False
candy_eater_game_over = False
candy_eater_guide = False
candy_eater_jump = False
candy_eater_score = 0
candy_eater_heart = 3
food_speed = 2



def update():
    global busy_street_score, left_car_speed, right_car_speed, busy_street_game_over, candy_eater_score, candy_eater_game_over, candy_eater_heart, food_speed
    #----------main menu buttons----------#
    if game_choosing == False and main_menu_exit == False :
        if game_center_logo.x != 510 :
            game_center_logo.x -= 5

        if games_button.y != 605 :
            games_button.y -= 5

        if info_button.y != 635 :
            info_button.y -= 5

        if shop_button.y != 635 :
            shop_button.y -= 5

        if exit_button.y != 635 :
            exit_button.y -= 5

        if setting_button.y != 635 :
            setting_button.y -= 5

    elif game_choosing:
        if game_center_logo.x == 510:
            game_center_logo.x = 1050

        if games_button.y == 605:
            games_button.y = 800

        if info_button.y == 635 :
            info_button.y = 700
    
        if shop_button.y == 635 :
            shop_button.y = 700
    
        if exit_button.y == 635 :
            exit_button.y = 700
            
        if setting_button.y == 635 :
            setting_button.y = 700

        if busy_street_logo.collidepoint(button_pos) :
            busy_street_logo.image = 'busy_street_logo_hover'
        elif candy_eater_logo.collidepoint(button_pos):
            candy_eater_logo.image = 'candy_eater_logo_hover'
        elif collector_logo.collidepoint(button_pos):
            collector_logo.image = 'collector_logo_hover'
        elif dino_logo.collidepoint(button_pos):
            dino_logo.image = 'dino_logo_hover'
        else:
            busy_street_logo.image = 'busy_street_logo_idle'
            candy_eater_logo.image = 'candy_eater_logo_idle'
            collector_logo.image = 'collector_logo_idle'
            dino_logo.image = 'dino_logo_idle'

    if games_button.collidepoint(button_pos) :
        games_button.image = 'games_button_hover'
    elif info_button.collidepoint(button_pos):
        info_button.image = 'info_button_hover'
    elif shop_button.collidepoint(button_pos):
        shop_button.image = 'shop_button_hover'
    elif exit_button.collidepoint(button_pos):
        exit_button.image = 'exit_button_hover'
    elif setting_button.collidepoint(button_pos):
        setting_button.image = 'setting_button_hover'
    elif yes_button.collidepoint(button_pos):
        yes_button.image = 'yes_hover'
    elif no_button.collidepoint(button_pos):
        no_button.image = 'no_hover'
    else:
        games_button.image = 'games_button_idle'
        info_button.image = 'info_button_idle'
        shop_button.image = 'shop_button_idle'
        exit_button.image = 'exit_button_idle'
        setting_button.image = 'setting_button_idle'
        yes_button.image = 'yes_idle'
        no_button.image = 'no_idle'

    #----------game choosing buttons----------#
    if main_menu_button.y != 605 and game_choosing:
        main_menu_button.y -= 5
    elif main_menu_button.y == 605 and game_choosing == False:
        main_menu_button.y = 800
    if main_menu_button.collidepoint(button_pos):
        main_menu_button.image = 'main_menu_button_hover'
    else:
        main_menu_button.image = 'main_menu_button_idle'

    #------------- common buttons -------------#
    if home_button.collidepoint(button_pos):
        home_button.image = 'home_button_hover'
    elif repeat_button.collidepoint(button_pos):
        repeat_button.image = 'repeat_button_hover'
    elif play_button.collidepoint(button_pos):
        play_button.image = 'play_button_hover'
    elif guide_button.collidepoint(button_pos):
        guide_button.image = 'guide_button_hover'
    elif music_on_button.collidepoint(button_pos) :
        music_on_button.image = 'music_on_button_hover'
    elif music_off_button.collidepoint(button_pos) :
            music_off_button.image = 'music_off_button_hover'
    else:
        repeat_button.image = 'repeat_button_idle'
        home_button.image = 'home_button_idle'
        play_button.image = 'play_button_idle'
        guide_button.image = 'guide_button_idle'
        music_on_button.image = 'music_on_button_idle'
        music_off_button.image = 'music_off_button_idle'



    #-------------- busy street game --------------#
    if busy_street_game and not busy_street_game_over :
        if keyboard.up and player_car.y >= 75 :
            player_car.y -= players_car_speed
        if keyboard.down :
            player_car.y += players_car_speed
        if player_car.y >= 850 :
            busy_street_score += 1
            player_car.y = -80
        
        left_car.x += left_car_speed
        if left_car.x >= 1100 :
            left_car.x = -100
            left_car.image = random.choice(left_car_list)
            left_car_speed = random.randint(2,15)
            left_car.x += left_car_speed
        
        right_car.x -= right_car_speed
        if right_car.x <= -100 :
            right_car.x = 1100
            right_car_speed = random.randint(2,15)
            right_car.x += right_car_speed

        if player_car.colliderect(left_car) or player_car.colliderect(right_car) :
            if music:
                sounds.car_crash.play()
            busy_street_game_over = True

        if score_button.collidepoint(button_pos):
            score_button.image = 'pink_score_button_hover'
        elif in_game_setting_button.collidepoint(button_pos):
            in_game_setting_button.image = 'pink_in_game_setting_hover'
        else:
            score_button.image = 'pink_score_button_idle'
            in_game_setting_button.image = 'pink_in_game_setting_idle'

    #---------------------------- candy eater game ---------------------------#
    if candy_eater_game and not candy_eater_game_over:

        #character movement#
        if keyboard.right and not pink_girl.x >= 940:
            pink_girl.x += 2
            pink_girl.flip_x = False
            if not keyboard.space and pink_girl.y >= 550 :
                pink_girl_walk.animate()
                pink_girl.image = pink_girl_walk.image
            
        elif keyboard.left and not pink_girl.x <= 58:
            pink_girl.x -= 2
            pink_girl.flip_x = True
            if not keyboard.space and pink_girl.y >= 550 :
                pink_girl_walk.animate()
                pink_girl.image = pink_girl_walk.image
            
        else :
            if pink_girl.flip_x == True :
                pink_girl.animate()
                pink_girl.flip_x = True
                pink_girl.image = pink_girl.image
            else:
                pink_girl.animate()
                pink_girl.flip_x = False
                pink_girl.image = pink_girl.image

        if candy_eater_jump :
            if pink_girl.flip_x :
                pink_girl.flip_x = True
            else :
                pink_girl.flip_x = False
            pink_girl.y -= 5
            pink_girl_jump_up.animate()
            pink_girl.image = pink_girl_jump_up.image
            if pink_girl.y <= 320 :
                candy_eater_jump = False

        elif not candy_eater_jump  and pink_girl.y != 550 :
            if pink_girl.flip_x :
                pink_girl.flip_x = True
            else :
                pink_girl.flip_x = False
            pink_girl_jump_down.animate()
            pink_girl.image = pink_girl_jump_down.image
            if pink_girl.y <= 550 :
                pink_girl.y += 5
            

        #food movement#
        unhealthy_food.y += food_speed
        if unhealthy_food.y >= HEIGHT + 50 :
            unhealthy_food.y = random.randrange(-151, -41 , 10)
            unhealthy_food.image = random.choice(unhealthy_food_list)
            unhealthy_food.x = random.randrange(60 + 1, 950 + 1 , 2)

        healthy_food.y += food_speed
        if healthy_food.y >= HEIGHT + 50 :
            healthy_food.y = random.randrange(-150, -40 , 10)
            healthy_food.image = random.choice(healthy_food_list)
            healthy_food.x = random.randrange(60 + 1, 950 + 1 , 2)

        #buttons#
        if score_button.collidepoint(button_pos):
            score_button.image = 'blue_score_button_hover'
        elif in_game_setting_button.collidepoint(button_pos):
            in_game_setting_button.image = 'blue_in_game_setting_hover'
        else:
            score_button.image = 'blue_score_button_idle'
            in_game_setting_button.image = 'blue_in_game_setting_idle'
        
        #score and level-up#
        if pink_girl.colliderect(unhealthy_food):
            if music:
                sounds.eating.play()
            candy_eater_score += 1
            if candy_eater_score == 5 or candy_eater_score == 10 or candy_eater_score == 15 :
                food_speed += 1
            unhealthy_food.y = random.randrange(-151, -41 , 10)
            unhealthy_food.x = random.randrange(60 + 1, 950 + 1 , 2)
            unhealthy_food.image = random.choice(unhealthy_food_list)

        #game over#
        if pink_girl.colliderect(healthy_food) :
            if music:
                sounds.ew.play()
            healthy_food.y = random.randrange(-150, -40 , 10)
            healthy_food.image = random.choice(healthy_food_list)
            healthy_food.x = random.randrange(60 + 1, 950 + 1 , 2)
            candy_eater_heart -= 1
            if candy_eater_score == 5 :
                food_speed += 1
            if candy_eater_heart == 0 :
                if music:
                    sounds.death.play()
                if pink_girl.flip_x :
                    pink_girl_dead.animate()
                    pink_girl.flip_x = True
                    pink_girl.image = pink_girl_dead.image
                else :
                    pink_girl_dead.animate()
                    pink_girl.flip_x = False
                    pink_girl.image = pink_girl_dead.image
                candy_eater_game_over = True
                food_speed = 0

"""if candy_eater_game and candy_eater_game_over and candy_eater_heart == 0 :
    if pink_girl.flip_x :
        pink_girl_dead.animate()
        pink_girl.flip_x = True
        pink_girl.image = pink_girl_dead.image
    else :
        pink_girl_dead.animate()
        pink_girl.flip_x = False
        pink_girl.image = pink_girl_dead.image"""



def draw():
    global main_menu

    def main_menu():
        global game_center_logo
        main_menu_background.draw()
        game_center_logo.draw()
        games_button.draw()
        setting_button.draw()
        exit_button.draw()
        shop_button.draw()
        info_button.draw()


    main_menu()

    if game_choosing :
        pink_background.draw()
        main_menu_button.draw()
        busy_street_logo.draw()
        candy_eater_logo.draw()
        collector_logo.draw()
        dino_logo.draw()

    if main_menu_exit :
        exit_panel.draw()
        yes_button.draw()
        no_button.draw()

    #---------------------------- busy street game ---------------------------#
    if busy_street_game :
        busy_street_road.draw()
        player_car.draw()
        left_car.draw()
        right_car.draw()
        black_lamp_1.draw()
        black_lamp_2.draw()
        black_lamp_3.draw()
        lamp_1.draw()
        lamp_2.draw()
        lamp_3.draw()
        lamp_4.draw()
        score_button.pos = 750, 100
        score_button.draw()
        in_game_setting_button.pos = 900, 100
        in_game_setting_button.draw()
        
        if score_button.collidepoint(button_pos):
            screen.draw.text(f'{busy_street_score}', fontsize = 25, topleft = (745, 110))
        else:
            screen.draw.text(f'{busy_street_score}', fontsize = 35, topleft = (745, 105))

        if in_game_setting :
            if busy_street_guide :
                busy_street_guide_panel.draw()
                play_button.pos = 650, 497
                key_up.pos = 331, 501
                key_down.pos = 450, 501
                key_up.draw()
                key_down.draw()
                if keyboard.up :
                    key_up.image = 'key_up_hover'
                else:
                    key_up.image = 'key_up_idle'
                if keyboard.down :
                    key_down.image = 'key_down_hover'
                else:
                    key_down.image = 'key_down_idle'
            else:
                pink_panel.draw()
                home_button.pos = 648, 105
                home_button.draw()
                play_button.pos = 648, 410
                guide_button.pos = 648, 258
                guide_button.draw()

                if music :
                    music_on_button.pos = 631, 565
                    music_on_button.draw()
                else :
                    music_off_button.pos = 631, 565
                    music_off_button.draw()
            play_button.draw()

        if busy_street_game_over and in_game_setting == False:
            pink_game_over_panel.draw()
            screen.draw.text(f'{busy_street_score}', fontsize = 100, topleft = (600, 280))
            repeat_button.pos = 354, 499
            repeat_button.draw()
            home_button.pos = 606, 499
            home_button.draw()

    #---------------------------- candy eater game ---------------------------#
    if candy_eater_game:
        candy_eater_background.draw()
        in_game_setting_button.pos = (915, 85)
        in_game_setting_button.draw()
        score_button.pos = 770, 85
        score_button.draw()
        #-----heart-----#
        if candy_eater_heart == 3 :
            heart_1.draw()
            heart_2.draw()
            heart_3.draw()
        elif candy_eater_heart == 2 :
            heart_1.draw()
            heart_2.draw()
        elif candy_eater_heart == 1 :
            heart_1.draw()

        if score_button.collidepoint(button_pos):
            screen.draw.text(f'{candy_eater_score}', fontsize = 25, topleft = (762, 98))
        else:
            screen.draw.text(f'{candy_eater_score}', fontsize = 35, topleft = (761, 93))

        unhealthy_food.draw()
        healthy_food.draw()
        pink_girl.draw()

        if candy_eater_game_over and in_game_setting == False:
            blue_game_over_logo.draw()
            home_button.pos = 100, 350
            home_button.draw()
            repeat_button.pos = 900, 350
            repeat_button.draw()

        if in_game_setting :
            if candy_eater_guide :
                candy_eater_guide_panel.draw()
                key_space.pos = 628, 559.5
                key_space.draw()
                key_left.pos = 336, 423
                key_left.draw()
                key_right.pos = 477, 423
                key_right.draw()
                if keyboard.left :
                    key_left.image = 'key_left_hover'
                else:
                    key_left.image = 'key_left_idle'
                if keyboard.right :
                    key_right.image = 'key_right_hover'
                else:
                    key_right.image = 'key_right_idle'
                if keyboard.space :
                    key_space.image = 'key_space_hover'
                else:
                    key_space.image = 'key_space_idle'

            else:
                blue_panel.draw()
                home_button.pos = 648, 105
                home_button.draw()
                play_button.pos = 648, 410
                guide_button.pos = 648, 258
                guide_button.draw()

                if music :
                    music_on_button.pos = 631, 565
                    music_on_button.draw()
                else :
                    music_off_button.pos = 631, 565
                    music_off_button.draw()
            play_button.draw()
                

        

        
def on_mouse_move(pos):
    global button_pos
    button_pos = pos

def on_mouse_down(pos, button):
    global game_choosing, busy_street_game, busy_street_game_over, main_menu_exit, busy_street_score, in_game_setting, music, busy_street_guide, candy_eater_game, candy_eater_game_over, candy_eater_score, candy_eater_heart, food_speed, candy_eater_guide
    
    #--------------------------music---------------------------#
    if music_on_button.collidepoint(pos) and music :
        music = False
    elif music_off_button.collidepoint(pos) and not music :
        music = True

    #----------------- main menu -----------------#
    if exit_button.collidepoint(pos):
        main_menu_exit = True
        button_out_of_screen()

    if no_button.collidepoint(pos) and main_menu_exit:
        main_menu_exit = False
    elif yes_button.collidepoint(pos) and main_menu_exit:
        quit()

    elif games_button.collidepoint(pos) and not busy_street_game and not candy_eater_game:
        game_choosing = True
    
    #----------------- game choosing -----------------#
    elif main_menu_button.collidepoint(pos) and game_choosing:
        game_choosing = False
        main_menu()

    elif busy_street_logo.collidepoint(pos) and game_choosing:
        if music:
            sounds.busy_street_start.play()
        busy_street_game = True
        busy_street_game_over = False
        game_choosing = False
    elif candy_eater_logo.collidepoint(pos) and game_choosing:
        candy_eater_game = True
        candy_eater_game_over = False
        game_choosing = False
    

    #---------------------------- busy street ----------------------------#
    if busy_street_game :
        if music and not busy_street_game_over :
            if button == mouse.LEFT and player_car.collidepoint(pos):
                sounds.horn1.play()
            elif button == mouse.LEFT and left_car.collidepoint(pos):
                sounds.horn2.play()
            elif button == mouse.LEFT and right_car.collidepoint(pos):
                sounds.horn3.play()
            elif button == mouse.LEFT and (lamp_1.collidepoint(pos) or lamp_2.collidepoint(pos)  or  lamp_3.collidepoint(pos) or lamp_4.collidepoint(pos)) :
                sounds.light_flicker.play()

        if guide_button.collidepoint(pos)  and in_game_setting:
            busy_street_guide = True

        if home_button.collidepoint(pos) and (busy_street_game_over and home_button.pos == 606, 499 or in_game_setting and home_button.pos == 648, 105):
            if in_game_setting:
                in_game_setting = False
            busy_street_game = False
            busy_street_game_over = False
            busy_street_score = 0
            player_car.pos = 562, 100
            right_car.pos = 900, 466
            left_car.pos = 100, 332
            main_menu()
        elif repeat_button.collidepoint(pos) and busy_street_game_over and not in_game_setting:
            busy_street_game_over = False
            busy_street_score = 0
            player_car.pos = 562, 100
            right_car.pos = 900, 466
            left_car.pos = 100, 332
        elif in_game_setting_button.collidepoint(pos) and not busy_street_game_over:
            in_game_setting = True
            busy_street_game_over = True
        elif play_button.collidepoint(pos):
            in_game_setting = False
            busy_street_guide = False
            busy_street_game_over = False

    #---------------------------- candy eater ----------------------------#
    elif candy_eater_game :
        if in_game_setting_button.collidepoint(pos) and not candy_eater_game_over:
            in_game_setting = True
            candy_eater_game_over = True
        elif repeat_button.collidepoint(pos) and candy_eater_game_over and not in_game_setting:
            unhealthy_food.image  = random.choice(unhealthy_food_list)
            unhealthy_food.pos = random.randint(60, 950), -20
            healthy_food.image = random.choice(healthy_food_list)
            healthy_food.pos = random.randint(60, 950), -20
            candy_eater_game_over = False
            candy_eater_score = 0
            candy_eater_heart = 3
            pink_girl.pos = 500, 550
            food_speed = 2
        elif home_button.collidepoint(pos) and candy_eater_game_over  and (busy_street_game_over and home_button.pos == 100, 350 or in_game_setting and home_button.pos == 648, 105):
            in_game_setting = False
            candy_eater_game = False
            candy_eater_game_over  = False
            unhealthy_food.image  = random.choice(unhealthy_food_list)
            unhealthy_food.pos = random.randint(60, 950), -20
            healthy_food.image = random.choice(healthy_food_list)
            healthy_food.pos = random.randint(60, 950), -20
            candy_eater_score = 0
            candy_eater_heart = 3
            pink_girl.pos = 500, 550
            food_speed = 2
        elif guide_button.collidepoint(pos) and in_game_setting :
            candy_eater_guide = True
        elif play_button.collidepoint(pos) and in_game_setting :
            candy_eater_game_over = False
            candy_eater_guide = False
            in_game_setting = False
        



def on_key_down(key):
    global candy_eater_jump
    if key == keys.SPACE and not busy_street_game_over and busy_street_game and music:
        sounds.horn4.play()

    if key == keys.SPACE and candy_eater_game and not candy_eater_game_over and pink_girl.y >= 550 :
        candy_eater_jump = True

pgzrun.go()